export const runtime = 'edge'

export async function POST(request) {
  try {
    const { image, mimeType } = await request.json()

    if (!image) {
      return Response.json({ error: 'No image provided' }, { status: 400 })
    }

    const apiKey = process.env.ANTHROPIC_API_KEY
    if (!apiKey) {
      return Response.json({ error: 'API key not configured. Please add ANTHROPIC_API_KEY in Vercel environment variables.' }, { status: 500 })
    }

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-haiku-4-5-20251001',
        max_tokens: 300,
        messages: [
          {
            role: 'user',
            content: [
              {
                type: 'image',
                source: {
                  type: 'base64',
                  media_type: mimeType || 'image/jpeg',
                  data: image,
                },
              },
              {
                type: 'text',
                text: `You are a waste segregation expert for India. Look at this image and classify the waste item.

Respond ONLY with valid JSON in this exact format (no markdown, no explanation):
{
  "item": "name of the item",
  "category": "one of: wet, dry, hazardous, ewaste, medical, construction",
  "confidence": number between 0-100,
  "reason": "one short sentence why"
}

Categories:
- wet: food waste, vegetables, fruit, cooked food, organic matter
- dry: paper, cardboard, plastic bottles, metal cans, glass, cloth, rubber
- hazardous: batteries, chemicals, paint, pesticides, motor oil, fluorescent bulbs
- ewaste: phones, laptops, cables, electronic components, chargers, circuit boards
- medical: syringes, medicine packaging, bandages, gloves, medical equipment
- construction: bricks, cement, tiles, wood planks, pipes, sand, gravel`,
              },
            ],
          },
        ],
      }),
    })

    if (!response.ok) {
      const errData = await response.json()
      return Response.json({ error: errData.error?.message || 'AI classification failed' }, { status: 500 })
    }

    const data = await response.json()
    const text = data.content[0]?.text || ''

    let parsed
    try {
      parsed = JSON.parse(text.trim())
    } catch {
      // Try to extract JSON from response
      const match = text.match(/\{[\s\S]*\}/)
      if (match) {
        parsed = JSON.parse(match[0])
      } else {
        throw new Error('Could not parse AI response')
      }
    }

    const validCategories = ['wet', 'dry', 'hazardous', 'ewaste', 'medical', 'construction']
    if (!validCategories.includes(parsed.category)) {
      parsed.category = 'dry'
    }

    return Response.json(parsed)
  } catch (err) {
    return Response.json({ error: err.message || 'Internal server error' }, { status: 500 })
  }
}
