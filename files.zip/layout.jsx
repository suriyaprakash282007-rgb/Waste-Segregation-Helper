export const metadata = {
  title: 'Waste Segregation Helper',
  description: 'AI-powered waste classification to help you segregate waste properly',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, fontFamily: 'system-ui, sans-serif', background: '#f0fdf4' }}>
        {children}
      </body>
    </html>
  )
}
