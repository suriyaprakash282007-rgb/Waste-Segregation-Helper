'use client'
import { useState, useRef } from 'react'

const categories = {
  wet: { label: 'Wet Waste', color: '#16a34a', bg: '#dcfce7', icon: '🟢', tip: 'Food scraps, vegetable peels, fruit waste, cooked food. Goes into GREEN bin.' },
  dry: { label: 'Dry Waste', color: '#2563eb', bg: '#dbeafe', icon: '🔵', tip: 'Paper, cardboard, plastics, metals, glass. Goes into BLUE bin.' },
  hazardous: { label: 'Hazardous Waste', color: '#dc2626', bg: '#fee2e2', icon: '🔴', tip: 'Batteries, chemicals, medicines, paint. Requires SPECIAL disposal.' },
  ewaste: { label: 'E-Waste', color: '#7c3aed', bg: '#ede9fe', icon: '🟣', tip: 'Electronics, phones, cables, bulbs. Take to certified E-WASTE centre.' },
  medical: { label: 'Medical Waste', color: '#d97706', bg: '#fef3c7', icon: '🟡', tip: 'Syringes, bandages, medicine strips. Needs MEDICAL waste disposal.' },
  construction: { label: 'Construction Waste', color: '#78716c', bg: '#f5f5f4', icon: '⚫', tip: 'Bricks, cement, tiles, sand. Contact municipal CONSTRUCTION waste unit.' },
}

export default function Home() {
  const [image, setImage] = useState(null)
  const [preview, setPreview] = useState(null)
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [dragOver, setDragOver] = useState(false)
  const fileInputRef = useRef()

  const handleFile = (file) => {
    if (!file || !file.type.startsWith('image/')) {
      setError('Please upload a valid image file.')
      return
    }
    setImage(file)
    setResult(null)
    setError(null)
    const reader = new FileReader()
    reader.onload = (e) => setPreview(e.target.result)
    reader.readAsDataURL(file)
  }

  const handleDrop = (e) => {
    e.preventDefault()
    setDragOver(false)
    handleFile(e.dataTransfer.files[0])
  }

  const classify = async () => {
    if (!image) return
    setLoading(true)
    setError(null)
    setResult(null)
    try {
      const reader = new FileReader()
      reader.onload = async (e) => {
        const base64 = e.target.result.split(',')[1]
        const res = await fetch('/api/classify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ image: base64, mimeType: image.type }),
        })
        const data = await res.json()
        if (!res.ok) throw new Error(data.error || 'Classification failed')
        setResult(data)
        setLoading(false)
      }
      reader.readAsDataURL(image)
    } catch (err) {
      setError(err.message)
      setLoading(false)
    }
  }

  const reset = () => {
    setImage(null)
    setPreview(null)
    setResult(null)
    setError(null)
  }

  const cat = result ? categories[result.category] : null

  return (
    <main style={{ minHeight: '100vh', padding: '24px 16px' }}>
      {/* Header */}
      <div style={{ textAlign: 'center', marginBottom: 32 }}>
        <div style={{ fontSize: 48, marginBottom: 8 }}>♻️</div>
        <h1 style={{ margin: 0, fontSize: 28, fontWeight: 800, color: '#14532d' }}>Waste Segregation Helper</h1>
        <p style={{ margin: '8px 0 0', color: '#166534', fontSize: 15 }}>
          Upload a photo of any waste item — AI will classify it for you
        </p>
      </div>

      <div style={{ maxWidth: 520, margin: '0 auto' }}>
        {/* Upload area */}
        {!result && (
          <div
            onClick={() => fileInputRef.current.click()}
            onDrop={handleDrop}
            onDragOver={(e) => { e.preventDefault(); setDragOver(true) }}
            onDragLeave={() => setDragOver(false)}
            style={{
              border: `2px dashed ${dragOver ? '#16a34a' : '#86efac'}`,
              borderRadius: 16,
              padding: 32,
              textAlign: 'center',
              cursor: 'pointer',
              background: dragOver ? '#f0fdf4' : '#ffffff',
              transition: 'all 0.2s',
              marginBottom: 16,
            }}
          >
            {preview ? (
              <img src={preview} alt="preview" style={{ maxWidth: '100%', maxHeight: 240, borderRadius: 12, objectFit: 'contain' }} />
            ) : (
              <>
                <div style={{ fontSize: 40, marginBottom: 12 }}>📷</div>
                <p style={{ margin: 0, fontWeight: 600, color: '#15803d' }}>Drop image here or click to upload</p>
                <p style={{ margin: '4px 0 0', fontSize: 13, color: '#4ade80' }}>JPG, PNG, WEBP supported</p>
              </>
            )}
            <input ref={fileInputRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={(e) => handleFile(e.target.files[0])} />
          </div>
        )}

        {/* Result */}
        {result && cat && (
          <div style={{ background: cat.bg, borderRadius: 16, padding: 24, marginBottom: 16, border: `2px solid ${cat.color}20` }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
              <span style={{ fontSize: 32 }}>{cat.icon}</span>
              <div>
                <div style={{ fontWeight: 800, fontSize: 20, color: cat.color }}>{cat.label}</div>
                <div style={{ fontSize: 13, color: '#374151' }}>Confidence: {result.confidence}%</div>
              </div>
            </div>
            {preview && <img src={preview} alt="uploaded" style={{ width: '100%', maxHeight: 200, objectFit: 'contain', borderRadius: 10, marginBottom: 12 }} />}
            <p style={{ margin: '0 0 8px', fontWeight: 600, color: '#1f2937' }}>Item: {result.item}</p>
            <p style={{ margin: 0, fontSize: 14, color: '#374151', background: '#fff8', padding: '10px 14px', borderRadius: 8 }}>{cat.tip}</p>
            {result.reason && <p style={{ margin: '10px 0 0', fontSize: 13, color: '#4b5563' }}>💡 {result.reason}</p>}
          </div>
        )}

        {/* Error */}
        {error && (
          <div style={{ background: '#fee2e2', border: '1px solid #fca5a5', borderRadius: 12, padding: '12px 16px', marginBottom: 16, color: '#991b1b', fontSize: 14 }}>
            ⚠️ {error}
          </div>
        )}

        {/* Buttons */}
        <div style={{ display: 'flex', gap: 12 }}>
          {!result ? (
            <button
              onClick={classify}
              disabled={!image || loading}
              style={{
                flex: 1, padding: '14px 24px', borderRadius: 12, border: 'none',
                background: image && !loading ? '#16a34a' : '#86efac',
                color: '#fff', fontWeight: 700, fontSize: 16,
                cursor: image && !loading ? 'pointer' : 'not-allowed',
                transition: 'background 0.2s',
              }}
            >
              {loading ? '🔍 Classifying...' : '🔍 Classify Waste'}
            </button>
          ) : (
            <button
              onClick={reset}
              style={{
                flex: 1, padding: '14px 24px', borderRadius: 12, border: 'none',
                background: '#16a34a', color: '#fff', fontWeight: 700, fontSize: 16, cursor: 'pointer',
              }}
            >
              📷 Classify Another Item
            </button>
          )}
        </div>

        {/* Category legend */}
        <div style={{ marginTop: 32 }}>
          <h3 style={{ color: '#14532d', fontSize: 15, marginBottom: 12 }}>Waste Categories</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            {Object.values(categories).map((c) => (
              <div key={c.label} style={{ background: c.bg, borderRadius: 10, padding: '10px 12px', display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: 18 }}>{c.icon}</span>
                <span style={{ fontSize: 13, fontWeight: 600, color: c.color }}>{c.label}</span>
              </div>
            ))}
          </div>
        </div>

        <p style={{ textAlign: 'center', fontSize: 12, color: '#86efac', marginTop: 24 }}>
          Powered by AI · Helping India segregate waste better 🇮🇳
        </p>
      </div>
    </main>
  )
}
